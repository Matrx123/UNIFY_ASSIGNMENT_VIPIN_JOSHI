const iState = {
    query: "",
    _data: []
}

const iStateDet = {
    _data : []
}

const reducer = (state = iState, action) => {
    if (action.type === "RESTRAUNTS") {
        return {
            _data: action.payload
        }
    }
    if (action.type === "SEARCH") {
        return {
            _data: action.payload
        }
    }
    return state;
}
export default reducer;
