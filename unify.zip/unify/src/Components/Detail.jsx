import React, { Component } from 'react';
import Image from '../Images/image.jpg';
import edit from '../Images/edit.svg';
import _delete from '../Images/delete.svg';
import '../Styles/style.css';
import { API_ITEM_DETAIL } from '../Constants/constant';
import { Link, Redirect } from 'react-router-dom';
import { deleteVendor } from '../AppUtil/UtilLib';


class Detail extends Component {
    constructor(props) {
        super(props)
        this.state = ({
            data: [],
        })
    }

    componentDidMount() {
        fetch(API_ITEM_DETAIL + this.props.location.state.itemID).then(res => res.json()).then(res2 => {
            this.setState({
                data: res2[0],
            })
        })
    }

    renderDetail = () => {
        return (
            <React.Fragment>
                <div className="det-Img">
                    <img src={Image} alt="not-found"></img>
                </div>
                <div className="muv-det">
                    <div className="title">
                        <h2>{this.state.data.Vendor_Name}</h2>
                        <div className="cast">
                            <h4>Address: {this.state.data.address}</h4>
                        </div>
                        <div className="description">
                            <h4>Description: {this.state.data.Description}</h4>
                        </div>
                    </div>
                    <div className="rating">
                        <h3>({this.state.data.rating})</h3>
                    </div>
                </div>
            </React.Fragment>
        );
    }

    deleteVendor = (id) => {
        deleteVendor(id).then(response => {
            this.setState({
                response: response.ok
            })
        }).catch(error => {

        });
    }

    render() {
        if (this.state.response) {
            return <Redirect
                to={{
                    pathname: "/"
                }} />;
        }
        else{
            return (
                <div>
                    <div className="detail-grid">
                        {
                            this.renderDetail()
                        }
                    </div>
                    <div className="btns">
                        <div className="buttons" title="edit">
                            <Link to={{
                                pathname: "/edit",
                                state: {
                                    itemID: this.state.data.id
                                }
                            }}>
                                <img src={edit} alt="edit"></img>
                            </Link>
                        </div>
                        <div className="buttonsDel" title="delete" onClick={() => { this.deleteVendor(this.state.data.id) }}>
                            <img src={_delete} alt="edit"></img>
                        </div>
                    </div>
                </div>
            );
        }
    }
}

export default Detail;