import React, { Component } from 'react';
import { connect } from 'react-redux';
import { restraunts, search } from '../Actions/action';
import CardView from './CardView';
import '../Styles/style.css';
import add from '../Images/add.png';
import { Link } from 'react-router-dom';

class Restraunts extends Component {
    constructor(props) {
        super(props)
    }
    componentDidMount() {


        this.props.getRestraunts();
    }
    render() {
        return (
            <div>
                <div className="container">
                    <div className="input-area">
                        <input className="searchBarText" type="text" placeholder="Search" onChange={(e) => {this.props.searchBar(e.target.value)}}></input>
                        <Link to={{
                              pathname:"/edit",
                              state: {
                               itemID: 0
                           }
                        }}>
                        <div className="add" title="Create an Entry">
                            <img src={add} alt="add-item"></img>
                        </div>
                        </Link>
                    </div>
                    <div className="cardView">
                        {
                            (this.props.data.length === 0)
                                ?
                                <h1></h1>
                                :
                                <div className="card-container">
                                    <main className="grid">
                                        {
                                            this.props.data.map(item =>
                                                <CardView {...item} />)
                                        }
                                    </main>
                                </div>
                        }
                    </div>
                </div>
            </div>
        );
    }
}
const mapStateToProps = (state) => {
    return ({
        data: state._data
    })
}
const mapDispatchToProps = (dispatch) => {
    return ({
        getRestraunts: () => { dispatch(restraunts()) },
        searchBar:(query)=>{dispatch(search(query))},
    })
}
export default connect(mapStateToProps, mapDispatchToProps)(Restraunts);