import React, { Component } from 'react';
import { API_ITEM_DETAIL } from '../Constants/constant';
import { editDet } from '../AppUtil/UtilLib';
import { Redirect } from 'react-router-dom';



class Edit extends Component {
    constructor(props) {
        super(props)
        this.state = {
            itemID: this.props.location.state.itemID,
        }
    }

    render() {
        return (
            <div className="edit-container">
                <div className="edit-content">
                    <h1 className="edit-title"></h1>
                    <LoginForm {...this.state} />
                </div>
            </div>
        );
    }
}

class LoginForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            Vendor_Name: '',
            rating: '',
            Description: '',
            address: '',
        };
        this.handleInputChange = this.handleInputChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentDidMount() {
        if (this.props.itemID === 0) {
            this.setState({
                Vendor_Name: '',
                rating: '',
                Description: '',
                address: '',
            })
        }
        else {
            fetch(API_ITEM_DETAIL + this.props.itemID).then(res => res.json()).then(res2 => {
                this.setState({
                    Vendor_Name: res2[0].Vendor_Name,
                    rating: res2[0].rating,
                    Description: res2[0].Description,
                    address: res2[0].address,
                })
            })
        }
    }

    handleInputChange(event) {
        const target = event.target;
        const inputName = target.name;
        const inputValue = target.value;

        this.setState({
            [inputName]: inputValue
        });
    }

    handleSubmit(event) {
        event.preventDefault();
        const loginRequest = Object.assign({}, this.state);
        editDet(loginRequest, this.props.itemID)
            .then(response => {
                this.setState({
                    response: response.ok
                })
            }).catch(error => {

            });
    }

    render() {
        if (this.state.response) {
            return <Redirect
                to={{
                    pathname: "/"
                }} />;
        }
        else {
            return (
                <form onSubmit={this.handleSubmit}>
                    <div className="editForm">
                        <div className="form-item">
                            <h3>Vendor Name</h3>
                            <input type="text" name="Vendor_Name"
                                className="form-control" placeholder="Vendor Name"
                                value={this.state.Vendor_Name} onChange={this.handleInputChange} required />
                        </div>
                        <div className="form-item">
                            <h3>Rating</h3>
                            <input type="text" name="rating"
                                className="form-control-rating" placeholder="Rating"
                                value={this.state.rating} onChange={this.handleInputChange} required />
                        </div>
                        <div className="form-item">
                            <h3>Description</h3>
                            <textarea name="Description"
                                className="form-control-txtDesc" placeholder="Description"
                                value={this.state.Description} onChange={this.handleInputChange} required />
                        </div>
                        <div className="form-item">
                            <h3>Address</h3>
                            <textarea name="address"
                                className="form-control-txtArea" placeholder="Address"
                                value={this.state.address} onChange={this.handleInputChange} required />
                        </div>
                    </div>
                    <div className="form-item">
                      {(this.props.itemID === 0) ?   <button type="submit" className="SubmitBtn">Add</button> :   <button type="submit" className="SubmitBtn">Update</button>}
                    </div>
                </form>
            );
        }
    }
}

export default Edit;
