import React from 'react';
import Image from '../Images/image.jpg'
import { Link } from 'react-router-dom';
const CardView = (props) => {
    return (

        <div className="cardItem" key={props.id}>
            <div className="cardImage">
                <div className="imgCard">
                    <Link to={{
                        pathname: "detail",
                        state: {
                            itemID: props.id
                        }
                    }}>
                        <img src={Image} alt="not-found"></img>
                    </Link>
                </div>
            </div>
            <div className="descGrid">
                <div className="cardDescription">
                    <Link style={{ textDecoration: 'none', color: 'black' }} to={{
                        pathname: "detail",
                        state: {
                            itemID: props.id
                        }
                    }}>
                        <h3 className="cardDescriptionHeading">{props.Vendor_Name}</h3>
                        <p className="cardDescriptionP">
                            {
                                props.Description
                            }
                        </p>
                    </Link>
                </div>
                <div className="rating">
                    <h4>
                        Rating ({props.rating})
                    </h4>
                </div>
            </div>
        </div>
    );
}
export default CardView;