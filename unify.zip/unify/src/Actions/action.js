import { API_BASE_URL, API_SEARCH_BASE_URL, API_ITEM_DETAIL } from '../Constants/constant';

export const restraunts = () => {
    return (dispatch) => {
        fetch(API_BASE_URL)
            .then(res => res.json())
            .then(res2 => {
                dispatch({
                    type: "RESTRAUNTS",
                    payload: res2,
                })
            })
    }
}

export const search = (query) =>{
    return(dispatch) =>{
        fetch(API_SEARCH_BASE_URL + query)
        .then(res =>res.json())
        .then(res2 =>{
            dispatch({
                type:"SEARCH",
                payload : res2,
            })
        })
    }
}