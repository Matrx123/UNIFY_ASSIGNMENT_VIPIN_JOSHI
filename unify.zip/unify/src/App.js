import React from 'react';
import { Switch, BrowserRouter as Router, Route } from 'react-router-dom';
import Restraunts from './Components/Restraunts';
import Detail from './Components/Detail';
import Edit from './Components/Edit';


function App() {
  return (
    <Router>
      <Switch>
        <Route exact path="/" component={Restraunts} />
        <Route exact path="/Detail" component={Detail} />
        <Route exact path="/Edit" component={Edit} />
      </Switch>
    </Router>
  );
}

export default App;
