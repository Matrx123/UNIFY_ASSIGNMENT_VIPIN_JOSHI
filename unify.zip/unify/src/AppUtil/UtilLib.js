import { API_BASE_URL } from "../Constants/constant";

const request = (options) => {
    const headers = new Headers({
        'Content-Type': 'application/json',
    })

    const defaults = { headers: headers };
    options = Object.assign({}, defaults, options);

    return fetch(options.url, options)
        .then(response =>
            response.json().then(json => {
                if (!response.ok) {
                    return Promise.reject(json);
                }
                return json.response = response;
            })
        );
};


export function editDet(loginRequest, id) {
    if (id !== 0) {
        return request({
            url: API_BASE_URL + "/" + id,
            method: 'PATCH',
            body: JSON.stringify(loginRequest)
        });
    }
    else {
        return request({
            url: API_BASE_URL,
            method: 'POST',
            body: JSON.stringify(loginRequest)
        });
    }
}

export function deleteVendor(id) {
    return request({
        url: API_BASE_URL + "/" + id,
        method: 'DELETE'
    });
}