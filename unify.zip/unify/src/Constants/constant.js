
export const API_BASE_URL = "http://localhost:3333/vendors"; 
export const API_SEARCH_BASE_URL = "http://localhost:3333/vendors?Vendor_Name_like=";
export const API_ITEM_DETAIL = "http://localhost:3333/vendors?id=";